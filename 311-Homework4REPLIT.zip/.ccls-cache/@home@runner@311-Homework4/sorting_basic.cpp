/**
 * Implemention of selected sorting algorithms
 * @file sorting.cpp
 */

#include "sorting.h"

/**
 * Implement the insertionSort algorithm correctly
 */
void insertionSort(int array[], int lowindex, int highindex, bool reversed) {
   for (int i = lowindex; i < highindex; i++) {

       if (reversed != true) {
           int curNode = array[i];
           int index = i - 1;
           while (index > 0 && curNode < array[index]) {
               array[index + i] = array[index]; //swap
               array[index] = curNode;
               index = index - 1;
           }
       }

       if (reversed == true) { // descending order
           int curNode = array[i];
           int index = i - 1;
           while (index >= 0 && curNode > array[index]) {
               array[index + i] = array[index]; // swap
               array[index] = curNode;
               index = index - 1;
           }
       }
   }
}


/**
 * @brief Implementation of the partition function used by quick sort
 * 
 */
int partition(int array[], int lowindex, int highindex, bool reversed) {
    int pivot = array[highindex];
    int pIndex = lowindex;

   if (reversed != true) { // ascending
        for (int i = lowindex; i < (highindex - 1); i++) {
            if (array[i] <= pivot) {  
                int temp = array[i];
                array[i] = array[pIndex];
                array[pIndex] = temp;
                pIndex++;
            }
        }
     }
  
  if (reversed == true) { // descending
        for (int i = lowindex; i < (highindex); i++) {
            if (array[i] >= pivot) {  //swap the pIndex with the pivot item
                int temp = array[i];
                array[i] = array[pIndex];
                array[pIndex] = temp;
                pIndex++;
            }
        }
    }
        int temp = array[highindex];
        array[highindex] = array[pIndex];
        array[pIndex] = temp;

        return pIndex;

}


/**
 * Implement the quickSort algorithm correctly
 */
    void quickSort(int array[], int lowindex, int highindex, bool reversed) {
        if (lowindex < highindex) { //start index will always be less than end index until thereis one element left
            int p = partition(array, lowindex, highindex, reversed);
            quickSort(array, lowindex, (p - 1)); // for the left partition
            quickSort(array, (p + 1), highindex); //for the right partition
        }
    }

