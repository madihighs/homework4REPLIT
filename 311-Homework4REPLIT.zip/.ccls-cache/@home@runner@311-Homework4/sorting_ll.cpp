/**
 * @brief You will implement the insertion sort and merge sort algorithms for a linked list in this file
 */
//You must complete the TODO parts and then complete LinkedList.cpp. Delete "TODO" after you are done.
//You should always comments to each function to describe its PURPOSE and PARAMETERS

#include "sorting.h"

/**
 * Implement the insertion sort algorithm for Linkedlist correctly
 */
LinkedList insertionSortLL(const LinkedList& list, bool reversed) {
    // TODO: Add your code here
}

/**
 * Implement the merge sort algorithm for LinkedList correctly
 */
LinkedList mergeSortLL(const LinkedList& list, bool reversed) {
    // TODO: Add your code here
}
