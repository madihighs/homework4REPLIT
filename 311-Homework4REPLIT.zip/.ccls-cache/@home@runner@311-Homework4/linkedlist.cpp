/**
 * @brief The implementation of the Linked List data structure
 */

//You must complete the TODO parts and then complete LinkedList.cpp. Delete "TODO" after you are done.

//- Make sure description and PARAMETER comments are given in detail
//  Highly recommended to copy HW3P1-help as PURPOSE of each function.
//  Add sufficient comments to your code body to describe what it does.
//      - Make sure all if-then-else are commented describing which case it is
//      - Make sure all local variables are described fully with their purposes

// ====================================================
//Your name: ??? (TODO: Add your name)
//Complier:  g++
//File type: linkedList.cpp implementation file
//=====================================================

#include<iostream>
#include"linkedlist.h"

using namespace std;

/**
 * @brief Destructor to destroy all nodes and release memory
 */
LinkedList::~LinkedList() {
   Node* curNode = front; //designate the front node as the current node
   while(curNode != nullptr){
       Node* nextPtr = curNode -> next; //set up for the next node
       delete curNode;
       count--;
       curNode = nextPtr; // make the next node the new node o be deleted
   }
   front = rear = nullptr; // establish that with an empty list front & rear = nullptr
}

/**
 * @brief Purpose: Checks if the list is empty
 * @return true if the list is empty, false otherwise
 */
bool LinkedList::isEmpty() const {
    if (front == nullptr){
        return true;
    }
    return false;
} 

/**
 * @brief  Get the number of nodes in the list
 * @return int The number of nodes in the list
 */
int LinkedList::length() const{
    Node* curNode = front; //start at front
     int count = 0;

     while (curNode != nullptr){ //keep moving until the end of list
         count++;
         curNode = curNode -> next;
     }
    return count;
}

/**
 * @brief Convert the list to a string
 *
 */
string LinkedList::toString() {
    string str = "[";
    Node *ptr = front;
    if (ptr != nullptr) {
        // Head node is not preceded by separator
        str += to_string(ptr->val);
        ptr = ptr->next;
    }
    while (ptr != nullptr) {
        str += ", " + to_string(ptr->val);
        ptr = ptr->next;
    }
    str  += "]";
    return str;
}

/**
 * @brief Displays the contents of the list
 */
void LinkedList::displayAll() {
    cout << toString() << endl;
}

//TODO: Add comments
void LinkedList::addRear(T val) {
    Node* newNode = new Node; // create new node and set the val to it
    newNode -> next = nullptr;
    newNode -> val = val;


    if(front == nullptr){  //if list was empty
        front = rear = newNode; // create its first node
    }
    else{
       rear -> next = newNode; // put the newNode at the end of the list
       rear = newNode; //make the new node the rear
    }
    count++;
}

void LinkedList::addFront(T val) {
    Node* newNode = new Node;
    newNode -> val = val;

    if(front == nullptr){  //if list was empty
        front = rear = newNode;
    }

    else  {
        newNode -> next = front; // point the newNodes next ptr to front node
        front = newNode; //make the newNode the front
    }
    count++;
} 

//TODO: Add comments
bool LinkedList::deleteFront(T &OldNum) {
    Node *temp = new Node; // create a temporary variable to store front
    temp = front;
    if(front == nullptr){ //the list was empty and returns false since empty
        return false;
    }
    else if(count == 1) {
        front = nullptr;
        rear = nullptr;
    }
    else {
        OldNum = front -> val; // sets front val to OldNum
        front = front -> next; //moves the front to the node after past front
        delete temp;
        count --;
    }
    return true;
}
// consider if the list was empty and return false if the list is empty
    // consider the special case of deleting the only node in the list

bool LinkedList::deleteRear(T &OldNum) {
    Node *curNode = front; // will point to the to be deleted node
    Node *prevNode = new Node; // will point to the node before it

    if(front == nullptr){ //the list was empty and returns false since empty
        return false;
    }

    curNode = front; // starts the curNode at the front of list

    if(curNode -> next != nullptr){ // until you get to the end of list
        prevNode = curNode; // prev node will be whatever curNode is until it gets to the end
        curNode = curNode -> next; //curNode will become the node after curNode
    }

    if (count == 1){
        front = nullptr;
        rear = nullptr;
    }

    rear = prevNode;
    prevNode -> next = nullptr; //new rear points to null
    OldNum = curNode -> val; // delete val
    delete curNode;
    count--;

    return true;

    // consider if the list was empty and return false if the list is empty
    // consider the special case of deleting the only node in the list
} 

/* --- harder ones for test 2 and 3 -- */

    /**
    * Implement the deleteAt function to delete a node at a given position.
    */
bool LinkedList::deleteAt(int pos, T &val) {
    if(pos < 1){
        cout <<"\nposition should be >= 1";
    }
    else if (pos == 1 && front != nullptr){
        Node* tobeDeleted = front;
        tobeDeleted ->val = val;
        front = front -> next;
        delete tobeDeleted;
        count--;
    }
    else{
        Node* temp = front;
        for(int i = 1; i < pos -1; i++){ //traverse to the node previous to the position
            if (temp != nullptr){
            temp = temp -> next;
            }
        }
            if (temp != nullptr && temp -> next != nullptr){
            Node* tobeDeleted = temp -> next;
            temp -> next =  temp -> next -> next;
            delete tobeDeleted;
            count--;
        }
            else{
            cout << "\n The list is already empty";
            }

    }


    //TODO: Add code here
    // check if the pos is valid first, then move the ptr to the rigth positon
    // consider the special case of deleting the first node and the last node
    // Do not forget to set value.
}

    /**
     * Implement the insertAt function here.
     */
bool LinkedList::insertAt(int pos, T val) {
    Node* newNode = new Node;
    newNode -> val = val;
    newNode -> next = nullptr;

    if(pos < 1 || pos == 1){ //if list is empty or being inserted at the front
        addFront(val);
    }
    else{
        Node* temp = front;
        for (int i = 1; i < pos - 1; i++){ // traverse through the list
            if (temp != nullptr){
                temp = temp -> next;
            }
        }
        if (temp != nullptr){
            newNode -> next = temp -> next; //draw it out
            temp -> next = newNode;
            count++;
        }
        else{
            cout << "List is full." << endl;
        }

    }

    //TODO: Add code here
    // check if the pos is valid first, then move the ptr to the rigth positon
    // consider the special case of inserting the first node and the last node
}

/**
 * @brief Copy Constructor to allow pass by value and return by value of a LinkedList
 * @param other LinkedList to be copied
 */
LinkedList::LinkedList(const LinkedList &other) {
    // Start with an empty list
    front = nullptr;
    rear = nullptr;
    count = 0;

    Node* ptr = other.front;
    for(int i =0; i < count; i++){
        this -> addRear(ptr -> val);
        ptr = ptr -> next;
    }
    // TODO: Add code here. Interate through the other list and add a new node to this list
    // for each node in the other list. The new node should have the same value as the other node.

}

/**
 * @brief Overloading of = (returns a reference to a LinkedList)
 * @param other LinkedList to be copied
 * @return reference to a LinkedList
 */
LinkedList& LinkedList::operator=(const LinkedList &other) {
    Node *curNode = new Node;
    int otherCount = other.length();
    if(this != &other) {
        if (front != 0) {
            Node *temp = curNode->next; //set up for the next node
            delete curNode;
            curNode = temp;
            otherCount--;
        }

    }
        else
        {
            // copy first node
            this->front = new Node;
            while(front != NULL);  // check allocation

            this->front ->val = other.front -> val;

            // copy rest of list
            Node *newPtr = front;  // new list pointer

            // newPtr points to last node in new list
            // origPtr points to nodes in original list
            for (Node *origPtr = other.front->next;
                 origPtr != nullptr;
                 origPtr = origPtr->next)
            {
                newPtr->next = new Node;   // link new node to end of list
                while(newPtr->next != nullptr);
                newPtr = newPtr->next;

                newPtr->val = origPtr->val;  // copy the data
                newPtr->next = nullptr;
                otherCount++;
            }
    }

    return *this;
}

/**
 * Implement the search function.
 * 
 * @return int: the position of the value in the list. If the value is not in the list, return -1.
 */
 int LinkedList::search(const T& val) const {
    // TODO: Add code here to complete the search function
    Node* curNode = front;
    int count = 0;
    while (curNode -> next != nullptr){
        if (curNode -> val == val){
            return count;
        }
        else{
            curNode = curNode -> next;
            count++;
        }
    }
    return -1;
}

